package com.example.android.miwok;

/**
 *
 */
public class Word {

    //m at the start for private variables.
    private String mDefaultTranslation;
    private String mMiwokTranslation;

    public Word(String vDefaultTranslation, String vMiwokTranslation){
        mDefaultTranslation =vDefaultTranslation;
        mMiwokTranslation = vMiwokTranslation;
    }

    public String getDefaultTranslation(){
        return mDefaultTranslation;
    }

    public String getMiwokTranslation(){
        return mMiwokTranslation;
    }

}
